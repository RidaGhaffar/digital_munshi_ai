-- ============================================================
-- DIGITAL MUNSHI - AUTH MIGRATION
-- Run this after schema.sql to add authentication columns
-- ============================================================

-- Add password_hash column to users table (if not exists)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255);

-- Add password_hash column to lawyers table (if not exists)
ALTER TABLE lawyers 
ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_users_email_unique ON users(email);
CREATE INDEX IF NOT EXISTS idx_admins_email_unique ON admins(email);
CREATE INDEX IF NOT EXISTS idx_lawyers_email_unique ON lawyers(email);

-- Create sample admin user (IMPORTANT: Change credentials in production!)
INSERT INTO admins (admin_id, email, password_hash, full_name, role, is_active)
VALUES (
  gen_random_uuid(),
  'admin@digitalmunshi.com',
  -- Pre-hashed password: 'admin123' (bcrypt)
  '$2b$12$d3dTm3X6e8P5J5pK9s7e0uL2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q',
  'Admin User',
  'super_admin',
  TRUE
)
ON CONFLICT (email) DO NOTHING;

-- Grant permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO postgres;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO postgres;

-- ============================================================
-- Verification queries
-- ============================================================

-- Check if columns exist:
-- SELECT column_name FROM information_schema.columns 
-- WHERE table_name='users' AND column_name='password_hash';

-- Check admin user:
-- SELECT admin_id, email, full_name, role FROM admins 
-- WHERE email = 'admin@digitalmunshi.com';
