-- ============================================================
-- MIGRATION: Add OCR Analysis Logs Table
-- Date: 2026-06-14
-- Description: Add table for storing OCR analysis history
-- ============================================================

-- Create OCR analysis logs table
CREATE TABLE IF NOT EXISTS ocr_analysis_logs (
  analysis_id         UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             UUID          NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  document_title      VARCHAR(300)  NOT NULL,
  analysis_type       VARCHAR(50)   NOT NULL
                        CHECK (analysis_type IN (
                          'summary','legal_analysis','action_items','classification'
                        )),
  extracted_text      TEXT          NOT NULL,
  ai_response         TEXT          NOT NULL,
  confidence_score    NUMERIC(5,4),
  created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_ocr_logs_user 
  ON ocr_analysis_logs(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_ocr_logs_type 
  ON ocr_analysis_logs(analysis_type);

CREATE INDEX IF NOT EXISTS idx_ocr_logs_date 
  ON ocr_analysis_logs(created_at DESC);

-- Grant permissions (if needed)
GRANT SELECT, INSERT, UPDATE ON ocr_analysis_logs TO PUBLIC;

-- Confirmation message
SELECT 'OCR Analysis Logs table created successfully!' AS migration_status;
