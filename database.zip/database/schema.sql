-- ============================================================
--  DIGITAL MUNSHI AI — COMPLETE POSTGRESQL SCHEMA
--  Version: 1.0  |  Timezone: PKT (UTC+5)
--  All PKs are UUIDs via gen_random_uuid()
-- ============================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS pg_trgm;   -- for full-text similarity search

-- ============================================================
-- 1. USERS
-- ============================================================
CREATE TABLE users (
  user_id               UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  firebase_uid          VARCHAR(128)  UNIQUE NOT NULL,
  email                 VARCHAR(255)  UNIQUE NOT NULL,
  full_name             VARCHAR(200)  NOT NULL,
  phone_number          VARCHAR(20),
  cnic_number           VARCHAR(15)   UNIQUE,
  preferred_language    VARCHAR(10)   NOT NULL DEFAULT 'en',
  profile_image_url     TEXT,
  is_active             BOOLEAN       NOT NULL DEFAULT TRUE,
  is_email_verified     BOOLEAN       NOT NULL DEFAULT FALSE,
  subscription_tier     VARCHAR(20)   NOT NULL DEFAULT 'free'
                          CHECK (subscription_tier IN ('free','premium')),
  total_queries_used    INTEGER       NOT NULL DEFAULT 0 CHECK (total_queries_used >= 0),
  monthly_queries_used  INTEGER       NOT NULL DEFAULT 0 CHECK (monthly_queries_used >= 0),
  created_at            TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  last_login_at         TIMESTAMPTZ
);

CREATE INDEX idx_users_email            ON users(email);
CREATE INDEX idx_users_firebase_uid     ON users(firebase_uid);
CREATE INDEX idx_users_subscription_tier ON users(subscription_tier);
CREATE INDEX idx_users_cnic             ON users(cnic_number) WHERE cnic_number IS NOT NULL;

-- ============================================================
-- 2. ADMINS
-- ============================================================
CREATE TABLE admins (
  admin_id      UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  email         VARCHAR(255)  UNIQUE NOT NULL,
  password_hash VARCHAR(255)  NOT NULL,
  full_name     VARCHAR(200)  NOT NULL,
  role          VARCHAR(50)   NOT NULL DEFAULT 'verifier'
                  CHECK (role IN ('super_admin','verifier','auditor')),
  is_active     BOOLEAN       NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  last_login_at TIMESTAMPTZ
);

-- ============================================================
-- 3. LAWYERS
-- ============================================================
CREATE TABLE lawyers (
  lawyer_id               UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  firebase_uid            VARCHAR(128)    UNIQUE NOT NULL,
  email                   VARCHAR(255)    UNIQUE NOT NULL,
  full_name               VARCHAR(200)    NOT NULL,
  phone_number            VARCHAR(20)     NOT NULL,
  cnic_number             VARCHAR(15)     UNIQUE NOT NULL,
  bar_council_license     VARCHAR(100)    UNIQUE NOT NULL,
  enrollment_number       VARCHAR(100)    NOT NULL,
  bar_council_name        VARCHAR(200)    NOT NULL,
  high_court_name         VARCHAR(200)    NOT NULL,
  years_of_experience     INTEGER         NOT NULL CHECK (years_of_experience >= 0),
  specialization_areas    TEXT[]          NOT NULL,
  office_address          TEXT            NOT NULL,
  city                    VARCHAR(100)    NOT NULL,
  province                VARCHAR(100)    NOT NULL
                            CHECK (province IN (
                              'Punjab','Sindh','KPK','Balochistan',
                              'Islamabad','AJK','GB','FATA'
                            )),
  profile_image_url       TEXT,
  profile_bio             TEXT,
  consultation_fee_pkr    NUMERIC(10,2)   NOT NULL DEFAULT 0 CHECK (consultation_fee_pkr >= 0),
  is_available_online     BOOLEAN         NOT NULL DEFAULT TRUE,
  availability_schedule   JSONB,
  verification_status     VARCHAR(30)     NOT NULL DEFAULT 'pending'
                            CHECK (verification_status IN (
                              'pending','under_review','approved','rejected','suspended'
                            )),
  verified_by_admin_id    UUID            REFERENCES admins(admin_id) ON DELETE SET NULL,
  verification_notes      TEXT,
  verified_at             TIMESTAMPTZ,
  average_rating          NUMERIC(3,2)    NOT NULL DEFAULT 0.00
                            CHECK (average_rating >= 0 AND average_rating <= 5),
  total_reviews           INTEGER         NOT NULL DEFAULT 0 CHECK (total_reviews >= 0),
  total_appointments      INTEGER         NOT NULL DEFAULT 0 CHECK (total_appointments >= 0),
  is_active               BOOLEAN         NOT NULL DEFAULT TRUE,
  created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_lawyers_status         ON lawyers(verification_status);
CREATE INDEX idx_lawyers_city           ON lawyers(city);
CREATE INDEX idx_lawyers_province       ON lawyers(province);
CREATE INDEX idx_lawyers_bar_license    ON lawyers(bar_council_license);
CREATE INDEX idx_lawyers_specialization ON lawyers USING GIN(specialization_areas);
CREATE INDEX idx_lawyers_rating         ON lawyers(average_rating DESC);
CREATE INDEX idx_lawyers_fee            ON lawyers(consultation_fee_pkr);

-- ============================================================
-- 4. LAWYER DOCUMENTS
-- ============================================================
CREATE TABLE lawyer_documents (
  document_id       UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  lawyer_id         UUID          NOT NULL REFERENCES lawyers(lawyer_id) ON DELETE CASCADE,
  document_type     VARCHAR(80)   NOT NULL
                      CHECK (document_type IN (
                        'bar_council_certificate','cnic_front','cnic_back',
                        'degree_certificate','high_court_enrollment',
                        'law_firm_affiliation','other'
                      )),
  file_url          TEXT          NOT NULL,
  file_name         VARCHAR(255)  NOT NULL,
  file_size_bytes   BIGINT        NOT NULL CHECK (file_size_bytes > 0),
  mime_type         VARCHAR(100)  NOT NULL,
  is_verified       BOOLEAN       NOT NULL DEFAULT FALSE,
  admin_comment     TEXT,
  uploaded_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_lawyer_docs_lawyer  ON lawyer_documents(lawyer_id);
CREATE INDEX idx_lawyer_docs_type    ON lawyer_documents(document_type);

-- ============================================================
-- 5. LAWYER VERIFICATIONS (Audit Trail)
-- ============================================================
CREATE TABLE lawyer_verifications (
  verification_id UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  lawyer_id       UUID         NOT NULL REFERENCES lawyers(lawyer_id) ON DELETE CASCADE,
  admin_id        UUID         NOT NULL REFERENCES admins(admin_id),
  action          VARCHAR(30)  NOT NULL
                    CHECK (action IN (
                      'started_review','approved','rejected',
                      'requested_more_docs','suspended'
                    )),
  notes           TEXT,
  created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_lawyer_verif_lawyer ON lawyer_verifications(lawyer_id, created_at DESC);
CREATE INDEX idx_lawyer_verif_admin  ON lawyer_verifications(admin_id);

-- ============================================================
-- 6. CHAT SESSIONS
-- ============================================================
CREATE TABLE chat_sessions (
  session_id        UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID          NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  session_title     VARCHAR(300),
  category          VARCHAR(80),
  language          VARCHAR(10)   NOT NULL DEFAULT 'en'
                      CHECK (language IN ('en','ur')),
  total_messages    INTEGER       NOT NULL DEFAULT 0 CHECK (total_messages >= 0),
  session_summary   TEXT,
  is_active         BOOLEAN       NOT NULL DEFAULT TRUE,
  created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  closed_at         TIMESTAMPTZ,
  last_activity_at  TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_user ON chat_sessions(user_id, last_activity_at DESC);
CREATE INDEX idx_sessions_active ON chat_sessions(is_active) WHERE is_active = TRUE;

-- ============================================================
-- 7. CHAT MESSAGES
-- ============================================================
CREATE TABLE chat_messages (
  message_id            UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id            UUID            NOT NULL REFERENCES chat_sessions(session_id) ON DELETE CASCADE,
  user_id               UUID            NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  role                  VARCHAR(10)     NOT NULL CHECK (role IN ('user','assistant')),
  content_text          TEXT            NOT NULL,
  content_language      VARCHAR(10)     NOT NULL DEFAULT 'en',
  input_type            VARCHAR(20)     NOT NULL DEFAULT 'text'
                          CHECK (input_type IN ('text','voice','document_paste')),
  ai_confidence_score   NUMERIC(5,4)
                          CHECK (ai_confidence_score IS NULL OR
                                 (ai_confidence_score >= 0 AND ai_confidence_score <= 1)),
  classified_category   VARCHAR(80),
  law_references        JSONB,
  draft_generated       BOOLEAN         NOT NULL DEFAULT FALSE,
  created_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_messages_session ON chat_messages(session_id, created_at DESC);
CREATE INDEX idx_messages_user    ON chat_messages(user_id, created_at DESC);

-- ============================================================
-- 8. USER MEMORY SUMMARIES (Long-Term AI Memory)
-- ============================================================
CREATE TABLE user_memory_summaries (
  memory_id                   UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                     UUID          UNIQUE NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  accumulated_summary         TEXT          NOT NULL,
  known_legal_categories      TEXT[]        NOT NULL DEFAULT '{}',
  known_entities              JSONB,
  total_sessions_summarized   INTEGER       NOT NULL DEFAULT 0 CHECK (total_sessions_summarized >= 0),
  last_updated_at             TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_memory_user ON user_memory_summaries(user_id);

-- ============================================================
-- 9. LEGAL DRAFTS
-- ============================================================
CREATE TABLE legal_drafts (
  draft_id        UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID          NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  session_id      UUID          REFERENCES chat_sessions(session_id) ON DELETE SET NULL,
  draft_type      VARCHAR(80)   NOT NULL
                    CHECK (draft_type IN (
                      'fir','legal_notice','complaint_application',
                      'affidavit','bail_application'
                    )),
  title           VARCHAR(300)  NOT NULL,
  draft_content   TEXT          NOT NULL,
  language        VARCHAR(10)   NOT NULL DEFAULT 'en'
                    CHECK (language IN ('en','ur')),
  form_data       JSONB,
  pdf_url         TEXT,
  is_exported     BOOLEAN       NOT NULL DEFAULT FALSE,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_drafts_user    ON legal_drafts(user_id, created_at DESC);
CREATE INDEX idx_drafts_type    ON legal_drafts(draft_type);
CREATE INDEX idx_drafts_session ON legal_drafts(session_id) WHERE session_id IS NOT NULL;

-- ============================================================
-- 10. UPLOADED DOCUMENTS (User OCR Documents)
-- ============================================================
CREATE TABLE uploaded_documents (
  doc_id                UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               UUID          NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  session_id            UUID          REFERENCES chat_sessions(session_id) ON DELETE SET NULL,
  file_url              TEXT          NOT NULL,
  original_filename     VARCHAR(255)  NOT NULL,
  mime_type             VARCHAR(100)  NOT NULL
                          CHECK (mime_type IN ('image/jpeg','image/png','application/pdf')),
  file_size_bytes       BIGINT        NOT NULL CHECK (file_size_bytes > 0),
  ocr_extracted_text    TEXT,
  ai_summary            TEXT,
  key_clauses           JSONB,
  predicted_category    VARCHAR(80),
  recommended_action    TEXT,
  processing_status     VARCHAR(30)   NOT NULL DEFAULT 'pending'
                          CHECK (processing_status IN ('pending','processing','completed','failed')),
  uploaded_at           TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_uploads_user    ON uploaded_documents(user_id, uploaded_at DESC);
CREATE INDEX idx_uploads_status  ON uploaded_documents(processing_status)
  WHERE processing_status IN ('pending','processing');

-- ============================================================
-- 11. SUBSCRIPTION PLANS
-- ============================================================
CREATE TABLE subscription_plans (
  plan_id                 UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_name               VARCHAR(100)    UNIQUE NOT NULL,
  display_name            VARCHAR(200)    NOT NULL,
  price_pkr               NUMERIC(10,2)   NOT NULL CHECK (price_pkr >= 0),
  billing_interval        VARCHAR(20)     NOT NULL
                            CHECK (billing_interval IN ('monthly','yearly','one_time')),
  max_queries_per_month   INTEGER,        -- NULL = unlimited
  includes_voice          BOOLEAN         NOT NULL DEFAULT FALSE,
  includes_drafts         BOOLEAN         NOT NULL DEFAULT FALSE,
  includes_ocr            BOOLEAN         NOT NULL DEFAULT FALSE,
  includes_appointments   BOOLEAN         NOT NULL DEFAULT FALSE,
  max_draft_exports       INTEGER,        -- NULL = unlimited
  is_active               BOOLEAN         NOT NULL DEFAULT TRUE,
  created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- ============================================================
-- 12. USER SUBSCRIPTIONS
-- ============================================================
CREATE TABLE user_subscriptions (
  subscription_id   UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID          NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  plan_id           UUID          NOT NULL REFERENCES subscription_plans(plan_id),
  status            VARCHAR(30)   NOT NULL DEFAULT 'active'
                      CHECK (status IN ('active','cancelled','expired','payment_failed')),
  started_at        TIMESTAMPTZ   NOT NULL,
  expires_at        TIMESTAMPTZ,
  cancelled_at      TIMESTAMPTZ,
  auto_renew        BOOLEAN       NOT NULL DEFAULT TRUE,
  payment_method    VARCHAR(50)
                      CHECK (payment_method IN ('jazzcash','easypaisa','card')),
  created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_subscriptions_user   ON user_subscriptions(user_id, created_at DESC);
CREATE INDEX idx_subscriptions_status ON user_subscriptions(status)
  WHERE status = 'active';

-- ============================================================
-- 13. APPOINTMENTS
-- ============================================================
CREATE TABLE appointments (
  appointment_id      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             UUID            NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  lawyer_id           UUID            NOT NULL REFERENCES lawyers(lawyer_id) ON DELETE CASCADE,
  session_id          UUID            REFERENCES chat_sessions(session_id) ON DELETE SET NULL,
  appointment_date    DATE            NOT NULL,
  appointment_time    TIME            NOT NULL,
  duration_minutes    INTEGER         NOT NULL DEFAULT 30 CHECK (duration_minutes > 0),
  appointment_type    VARCHAR(30)     NOT NULL DEFAULT 'online'
                        CHECK (appointment_type IN ('online','in_person')),
  case_description    TEXT            NOT NULL CHECK (LENGTH(case_description) >= 50),
  case_category       VARCHAR(80),
  relevant_documents  TEXT[],
  meeting_link        TEXT,
  status              VARCHAR(30)     NOT NULL DEFAULT 'pending'
                        CHECK (status IN (
                          'pending','confirmed','completed','cancelled','no_show'
                        )),
  fee_pkr             NUMERIC(10,2)   NOT NULL CHECK (fee_pkr >= 0),
  is_paid             BOOLEAN         NOT NULL DEFAULT FALSE,
  lawyer_notes        TEXT,
  created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- Prevent double-booking for same lawyer time slot
CREATE UNIQUE INDEX idx_appointments_no_conflict
  ON appointments(lawyer_id, appointment_date, appointment_time)
  WHERE status NOT IN ('cancelled','no_show');

CREATE INDEX idx_appointments_user   ON appointments(user_id, appointment_date DESC);
CREATE INDEX idx_appointments_lawyer ON appointments(lawyer_id, appointment_date DESC);
CREATE INDEX idx_appointments_status ON appointments(status);
CREATE INDEX idx_appointments_date   ON appointments(appointment_date);

-- ============================================================
-- 14. PAYMENT TRANSACTIONS
-- ============================================================
CREATE TABLE payment_transactions (
  transaction_id          UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                 UUID            NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  subscription_id         UUID            REFERENCES user_subscriptions(subscription_id) ON DELETE SET NULL,
  appointment_id          UUID            REFERENCES appointments(appointment_id) ON DELETE SET NULL,
  amount_pkr              NUMERIC(10,2)   NOT NULL CHECK (amount_pkr > 0),
  payment_method          VARCHAR(50)     NOT NULL
                            CHECK (payment_method IN ('jazzcash','easypaisa','card')),
  gateway_transaction_id  VARCHAR(200)    UNIQUE NOT NULL,
  status                  VARCHAR(30)     NOT NULL
                            CHECK (status IN ('pending','completed','failed','refunded')),
  payment_type            VARCHAR(30)     NOT NULL
                            CHECK (payment_type IN ('subscription','appointment')),
  created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
  -- Enforce: exactly one of subscription_id or appointment_id must be set
  CONSTRAINT chk_payment_target CHECK (
    (subscription_id IS NOT NULL AND appointment_id IS NULL) OR
    (subscription_id IS NULL AND appointment_id IS NOT NULL)
  )
);

CREATE INDEX idx_transactions_user   ON payment_transactions(user_id, created_at DESC);
CREATE INDEX idx_transactions_status ON payment_transactions(status);
CREATE INDEX idx_transactions_type   ON payment_transactions(payment_type);

-- ============================================================
-- 15. APPOINTMENT REVIEWS
-- ============================================================
CREATE TABLE appointment_reviews (
  review_id       UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id  UUID        UNIQUE NOT NULL REFERENCES appointments(appointment_id) ON DELETE CASCADE,
  user_id         UUID        NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  lawyer_id       UUID        NOT NULL REFERENCES lawyers(lawyer_id) ON DELETE CASCADE,
  rating          INTEGER     NOT NULL CHECK (rating BETWEEN 1 AND 5),
  review_text     TEXT,
  is_anonymous    BOOLEAN     NOT NULL DEFAULT FALSE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_reviews_lawyer ON appointment_reviews(lawyer_id, created_at DESC);
CREATE INDEX idx_reviews_user   ON appointment_reviews(user_id);

-- ============================================================
-- 16. NOTIFICATIONS
-- ============================================================
CREATE TABLE notifications (
  notification_id     UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_user_id   UUID          REFERENCES users(user_id) ON DELETE CASCADE,
  recipient_lawyer_id UUID          REFERENCES lawyers(lawyer_id) ON DELETE CASCADE,
  notification_type   VARCHAR(80)   NOT NULL
                        CHECK (notification_type IN (
                          'appointment_confirmed','appointment_reminder',
                          'verification_approved','verification_rejected',
                          'payment_received','new_review','subscription_expiry'
                        )),
  title               VARCHAR(200)  NOT NULL,
  message             TEXT          NOT NULL,
  is_read             BOOLEAN       NOT NULL DEFAULT FALSE,
  related_entity_id   UUID,
  created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  -- Enforce: at least one recipient must be set
  CONSTRAINT chk_notification_recipient CHECK (
    recipient_user_id IS NOT NULL OR recipient_lawyer_id IS NOT NULL
  )
);

CREATE INDEX idx_notifications_user   ON notifications(recipient_user_id, created_at DESC)
  WHERE recipient_user_id IS NOT NULL;
CREATE INDEX idx_notifications_lawyer ON notifications(recipient_lawyer_id, created_at DESC)
  WHERE recipient_lawyer_id IS NOT NULL;
CREATE INDEX idx_notifications_unread ON notifications(is_read)
  WHERE is_read = FALSE;

-- ============================================================
-- 17. OCR ANALYSIS LOGS
-- ============================================================
CREATE TABLE ocr_analysis_logs (
  analysis_id         UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             UUID          NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  document_title      VARCHAR(300)  NOT NULL,
  analysis_type       VARCHAR(50)   NOT NULL
                        CHECK (analysis_type IN (
                          'summary','legal_analysis','action_items','classification'
                        )),
  extracted_text      TEXT          NOT NULL,
  ai_response         TEXT          NOT NULL,
  confidence_score    NUMERIC(5,4),
  created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_ocr_logs_user     ON ocr_analysis_logs(user_id, created_at DESC);
CREATE INDEX idx_ocr_logs_type     ON ocr_analysis_logs(analysis_type);
CREATE INDEX idx_ocr_logs_date     ON ocr_analysis_logs(created_at DESC);

-- ============================================================
-- AUTO-UPDATE TRIGGERS (updated_at columns)
-- ============================================================
CREATE OR REPLACE FUNCTION fn_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();

CREATE TRIGGER trg_lawyers_updated_at
  BEFORE UPDATE ON lawyers
  FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();

CREATE TRIGGER trg_appointments_updated_at
  BEFORE UPDATE ON appointments
  FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();

-- ============================================================
-- AUTO-UPDATE LAWYER STATS AFTER REVIEW
-- ============================================================
CREATE OR REPLACE FUNCTION fn_update_lawyer_rating()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE lawyers
  SET
    average_rating = (
      SELECT ROUND(AVG(rating)::NUMERIC, 2)
      FROM appointment_reviews
      WHERE lawyer_id = NEW.lawyer_id
    ),
    total_reviews = (
      SELECT COUNT(*)
      FROM appointment_reviews
      WHERE lawyer_id = NEW.lawyer_id
    )
  WHERE lawyer_id = NEW.lawyer_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_lawyer_rating
  AFTER INSERT OR UPDATE ON appointment_reviews
  FOR EACH ROW EXECUTE FUNCTION fn_update_lawyer_rating();

-- ============================================================
-- AUTO-INCREMENT LAWYER APPOINTMENT COUNT
-- ============================================================
CREATE OR REPLACE FUNCTION fn_increment_lawyer_appointments()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
    UPDATE lawyers
    SET total_appointments = total_appointments + 1
    WHERE lawyer_id = NEW.lawyer_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_increment_lawyer_appointments
  AFTER UPDATE ON appointments
  FOR EACH ROW EXECUTE FUNCTION fn_increment_lawyer_appointments();

-- ============================================================
-- AUTO-UPDATE CHAT SESSION MESSAGE COUNT
-- ============================================================
CREATE OR REPLACE FUNCTION fn_update_session_message_count()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE chat_sessions
  SET
    total_messages   = total_messages + 1,
    last_activity_at = NOW()
  WHERE session_id = NEW.session_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_session_on_message
  AFTER INSERT ON chat_messages
  FOR EACH ROW EXECUTE FUNCTION fn_update_session_message_count();

-- ============================================================
-- SEED DATA — SUBSCRIPTION PLANS
-- ============================================================
INSERT INTO subscription_plans (
  plan_name, display_name, price_pkr, billing_interval,
  max_queries_per_month, includes_voice, includes_drafts,
  includes_ocr, includes_appointments, max_draft_exports
) VALUES
(
  'free',
  'Free Plan',
  0.00, 'monthly',
  10, FALSE, FALSE, FALSE, FALSE, 0
),
(
  'premium_monthly',
  'Premium Monthly Plan',
  799.00, 'monthly',
  NULL, TRUE, TRUE, TRUE, TRUE, NULL
),
(
  'premium_yearly',
  'Premium Yearly Plan (Best Value)',
  7499.00, 'yearly',
  NULL, TRUE, TRUE, TRUE, TRUE, NULL
);

-- ============================================================
-- VIEWS
-- ============================================================

-- Active verified lawyers (used by public browsing)
CREATE OR REPLACE VIEW vw_approved_lawyers AS
SELECT
  lawyer_id, full_name, email, phone_number,
  specialization_areas, city, province,
  consultation_fee_pkr, is_available_online,
  availability_schedule, average_rating,
  total_reviews, total_appointments,
  profile_image_url, profile_bio
FROM lawyers
WHERE verification_status = 'approved'
  AND is_active = TRUE;

-- User dashboard summary
CREATE OR REPLACE VIEW vw_user_dashboard AS
SELECT
  u.user_id, u.full_name, u.email,
  u.subscription_tier, u.monthly_queries_used, u.total_queries_used,
  sp.max_queries_per_month,
  sp.includes_voice, sp.includes_drafts,
  sp.includes_ocr, sp.includes_appointments,
  COUNT(DISTINCT cs.session_id)  AS total_sessions,
  COUNT(DISTINCT ld.draft_id)    AS total_drafts,
  COUNT(DISTINCT a.appointment_id) AS total_appointments
FROM users u
LEFT JOIN user_subscriptions us
  ON us.user_id = u.user_id AND us.status = 'active'
LEFT JOIN subscription_plans sp ON sp.plan_id = us.plan_id
LEFT JOIN chat_sessions cs       ON cs.user_id = u.user_id
LEFT JOIN legal_drafts ld         ON ld.user_id = u.user_id
LEFT JOIN appointments a          ON a.user_id = u.user_id
GROUP BY u.user_id, sp.max_queries_per_month,
         sp.includes_voice, sp.includes_drafts,
         sp.includes_ocr, sp.includes_appointments;

-- ============================================================
-- END OF SCHEMA
-- ============================================================
