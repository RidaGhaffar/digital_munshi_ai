import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import os

class QueryClassifier:
    def __init__(self):
        model_path = os.path.join(os.path.dirname(__file__), '../models/bert_classifier')
        
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Category mapping
        self.id2label = {
            0: 'Consumer',
            1: 'Criminal',
            2: 'Family',
            3: 'Labor',
            4: 'Property',
            5: 'Tenant'
        }
        
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(model_path)
            self.model = AutoModelForSequenceClassification.from_pretrained(model_path)
            self.model.to(self.device)
            self.model.eval()
            print(f"✅ BERT Classifier loaded on {self.device}")
            print(f"✅ Categories: {list(self.id2label.values())}")
        except Exception as e:
            print(f"❌ Error loading model: {e}")
            self.model = None
    
    def classify(self, query):
        """Classify the legal query into Pakistani law categories"""
        if self.model is None:
            return {'category': 'General', 'confidence': 0.0}
        
        if not query or not query.strip():
            return {'category': 'General', 'confidence': 0.0}
        
        try:
            inputs = self.tokenizer(query, return_tensors='pt', truncation=True, max_length=512)
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            with torch.no_grad():
                outputs = self.model(**inputs)
                logits = outputs.logits
                scores = torch.softmax(logits, dim=1)
                label = torch.argmax(scores, dim=1).item()
                confidence = scores[0][label].item()
            
            # Get category name
            category = self.id2label.get(label, 'General')
            
            # Get all scores
            all_scores = {}
            for idx, score in enumerate(scores[0]):
                cat_name = self.id2label.get(idx, f'Unknown_{idx}')
                all_scores[cat_name] = round(score.item(), 3)
            
            # --- Low-confidence -> General ---
            CONFIDENCE_THRESHOLD = 0.50
            
            if confidence < CONFIDENCE_THRESHOLD:
                category = 'General'
            
            print(f"✅ Classified '{query[:50]}...' as {category} ({confidence*100:.1f}%)")
            
            return {
                'category': category,
                'confidence': round(confidence, 3),
                'all_scores': all_scores,
                'label_id': label
            }
        except Exception as e:
            print(f"❌ Classification error: {e}")
            return {'category': 'General', 'confidence': 0.0}