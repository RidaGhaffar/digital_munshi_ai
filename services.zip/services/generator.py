from transformers import pipeline
import torch


class AnswerGenerator:
    def __init__(self):
        self.device = 0 if torch.cuda.is_available() else -1

        try:
            self.generator = pipeline(
                'summarization',
                model='facebook/bart-large-cnn',
                device=self.device
            )
            print("✅ Generator loaded")
        except Exception as e:
            print("❌ Generator error:", e)
            self.generator = None

    def generate(self, question, documents, classification, history=None):

        if not documents:
            return {
                'answer': 'Maafi kijiye, relevant information nahi mili.',
                'sources': [],
                'document_count': 0
            }

        try:
            # ===== Documents context =====
            docs_context = "\n\n".join([
                f"{doc['title']}\n{doc['content']}"
                for doc in documents
            ])

            # ===== History context =====
            history_text = ""
            if history:
                history_text = "\n".join(history)

            # ===== FINAL PROMPT =====
            prompt = f"""
You are a helpful assistant for Pakistani law.

Conversation History:
{history_text}

Relevant Documents:
{docs_context}

User Question:
{question}

Answer clearly in simple Roman Urdu or English.
"""

            # ===== Generate =====
            if self.generator:
                try:
                    result = self.generator(
                        prompt,
                        max_length=180,
                        min_length=60,
                        do_sample=False
                    )
                    answer = result[0]['summary_text']
                except Exception as e:
                    print("⚠️ Model error:", e)
                    answer = prompt[:600]
            else:
                answer = prompt[:600]

            return {
                'answer': answer,
                'sources': [d['title'] for d in documents],
                'document_count': len(documents)
            }

        except Exception as e:
            return {
                'answer': f"Error: {str(e)}",
                'sources': [],
                'document_count': 0
            }