"""OCR Service using PaddleOCR"""
import os
import io
import logging

logger = logging.getLogger(__name__)

# Try to import PaddleOCR, but make it optional
try:
    from paddleocr import PaddleOCR
    PADDLEOCR_AVAILABLE = True
except ImportError:
    PADDLEOCR_AVAILABLE = False
    logger.warning("PaddleOCR not installed. Install with: pip install paddleocr")

try:
    from PIL import Image
except ImportError:
    Image = None
    logger.warning("Pillow not installed. Install with: pip install Pillow")

try:
    import fitz  # PyMuPDF
    PYMUPDF_AVAILABLE = True
except ImportError:
    PYMUPDF_AVAILABLE = False
    logger.warning("PyMuPDF not installed. Install with: pip install PyMuPDF")


class OCRService:
    """Service for Optical Character Recognition using PaddleOCR"""
    
    def __init__(self, languages=None):
        """Initialize PaddleOCR with specified languages
        
        Args:
            languages: Comma-separated string of language codes
                      Default: 'en' for English only (most stable)
        """
        if languages is None:
            languages = 'en'
        
        # Convert list to string if needed
        if isinstance(languages, list):
            languages = ','.join(languages)
        
        self.ocr = None
        
        if not PADDLEOCR_AVAILABLE:
            logger.warning("PaddleOCR is not available. OCR features will be disabled.")
            return
        
        try:
            self.ocr = PaddleOCR(
                lang=languages       # Must be string like 'en' or 'en,ur'
            )
            logger.info(f"PaddleOCR initialized with languages: {languages}")
        except Exception as e:
            logger.error(f"Failed to initialize PaddleOCR: {str(e)}")
            self.ocr = None
    
    def _run_ocr_on_image_path(self, image_path):
        """Run PaddleOCR on a single image file and return text + confidences"""
        extracted_text = []
        confidences = []
        
        result = self.ocr.ocr(image_path, cls=True)
        
        if result and len(result) > 0:
            for line in result:
                if line:
                    for word_info in line:
                        text = word_info[1]
                        confidence = word_info[2]
                        extracted_text.append(text)
                        confidences.append(confidence)
        
        return extracted_text, confidences
    
    def _convert_pdf_to_images(self, pdf_path, output_dir='/tmp', dpi=200):
        """Convert each page of a PDF into a PNG image using PyMuPDF
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to save page images
            dpi: Resolution for rendering pages
            
        Returns:
            list: Paths to generated page images
        """
        if not PYMUPDF_AVAILABLE:
            raise RuntimeError("PyMuPDF (fitz) is not installed. Run: pip install PyMuPDF")
        
        image_paths = []
        doc = fitz.open(pdf_path)
        
        zoom = dpi / 72  # 72 is the default PDF DPI
        matrix = fitz.Matrix(zoom, zoom)
        
        base_name = os.path.splitext(os.path.basename(pdf_path))[0]
        
        for page_num in range(len(doc)):
            page = doc[page_num]
            pix = page.get_pixmap(matrix=matrix)
            image_path = os.path.join(output_dir, f"{base_name}_page_{page_num + 1}.png")
            pix.save(image_path)
            image_paths.append(image_path)
        
        doc.close()
        return image_paths
    
    def _extract_from_pdf(self, pdf_path):
        """Extract text from a PDF by converting pages to images and running OCR
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            dict: Same structure as extract_text_from_file
        """
        page_image_paths = []
        try:
            page_image_paths = self._convert_pdf_to_images(pdf_path)
            
            if not page_image_paths:
                return {
                    'status': 'error',
                    'text': '',
                    'confidence': 0,
                    'error': 'PDF has no pages or could not be converted to images'
                }
            
            all_text = []
            all_confidences = []
            
            for page_image_path in page_image_paths:
                text_list, conf_list = self._run_ocr_on_image_path(page_image_path)
                all_text.extend(text_list)
                all_confidences.extend(conf_list)
            
            full_text = ' '.join(all_text)
            avg_confidence = sum(all_confidences) / len(all_confidences) if all_confidences else 0
            
            return {
                'status': 'success',
                'text': full_text,
                'confidence': round(avg_confidence, 4),
                'error': None,
                'character_count': len(full_text)
            }
        
        except Exception as e:
            logger.error(f"PDF OCR extraction failed for {pdf_path}: {str(e)}")
            return {
                'status': 'error',
                'text': '',
                'confidence': 0,
                'error': f'PDF OCR processing failed: {str(e)}'
            }
        
        finally:
            # Clean up generated page images
            for image_path in page_image_paths:
                try:
                    os.remove(image_path)
                except:
                    pass
    
    def extract_text_from_file(self, file_path):
        """Extract text from an image or PDF file
        
        Args:
            file_path: Path to the image/PDF file
            
        Returns:
            dict: Contains extracted text and metadata
                {
                    'status': 'success' or 'error',
                    'text': 'extracted text',
                    'confidence': average_confidence_score,
                    'error': 'error message if any',
                    'character_count': number of characters
                }
        """
        if not self.ocr:
            return {
                'status': 'error',
                'text': '',
                'confidence': 0,
                'error': 'OCR service not initialized'
            }
        
        try:
            # Validate file exists
            if not os.path.exists(file_path):
                return {
                    'status': 'error',
                    'text': '',
                    'confidence': 0,
                    'error': f'File not found: {file_path}'
                }
            
            # Handle PDF files separately
            if file_path.lower().endswith('.pdf'):
                return self._extract_from_pdf(file_path)
            
            # Run OCR on image
            extracted_text, confidences = self._run_ocr_on_image_path(file_path)
            
            full_text = ' '.join(extracted_text)
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            
            return {
                'status': 'success',
                'text': full_text,
                'confidence': round(avg_confidence, 4),
                'error': None,
                'character_count': len(full_text)
            }
        
        except Exception as e:
            logger.error(f"OCR extraction failed for {file_path}: {str(e)}")
            return {
                'status': 'error',
                'text': '',
                'confidence': 0,
                'error': f'OCR processing failed: {str(e)}'
            }
    
    def extract_text_from_bytes(self, file_bytes, filename='image.jpg'):
        """Extract text from file bytes (from upload)
        
        Args:
            file_bytes: File content as bytes
            filename: Original filename (used to detect file type and for temp file)
            
        Returns:
            dict: Same structure as extract_text_from_file
        """
        if not self.ocr:
            return {
                'status': 'error',
                'text': '',
                'confidence': 0,
                'error': 'OCR service not initialized'
            }
        
        temp_path = None
        try:
            os.makedirs('/tmp', exist_ok=True)
            
            is_pdf = filename.lower().endswith('.pdf')
            
            if is_pdf:
                # Save PDF bytes directly to a temp file
                temp_path = f'/tmp/{filename}'
                with open(temp_path, 'wb') as f:
                    f.write(file_bytes)
                
                result = self._extract_from_pdf(temp_path)
            
            else:
                # Convert bytes to image and save temporarily
                image = Image.open(io.BytesIO(file_bytes))
                temp_path = f'/tmp/{filename}'
                image.save(temp_path)
                
                extracted_text, confidences = self._run_ocr_on_image_path(temp_path)
                
                full_text = ' '.join(extracted_text)
                avg_confidence = sum(confidences) / len(confidences) if confidences else 0
                
                result = {
                    'status': 'success',
                    'text': full_text,
                    'confidence': round(avg_confidence, 4),
                    'error': None,
                    'character_count': len(full_text)
                }
            
            return result
        
        except Exception as e:
            logger.error(f"OCR extraction from bytes failed: {str(e)}")
            return {
                'status': 'error',
                'text': '',
                'confidence': 0,
                'error': f'OCR processing failed: {str(e)}'
            }
        
        finally:
            # Clean up temp file
            if temp_path:
                try:
                    os.remove(temp_path)
                except:
                    pass
    
    def batch_extract_text(self, file_paths):
        """Extract text from multiple files
        
        Args:
            file_paths: List of file paths
            
        Returns:
            dict: Mapping of filenames to OCR results
        """
        results = {}
        for file_path in file_paths:
            filename = os.path.basename(file_path)
            results[filename] = self.extract_text_from_file(file_path)
        return results


# Initialize global OCR service
ocr_service = OCRService(languages='en')