# ============================================================
# DigitalMunshi — services/retriever.py
# LangChain FAISS + BAAI/bge-small-en-v1.5 embeddings
# RAG notebook ke same model use ho raha hai
# ============================================================

import os
import logging
from typing import List

logger = logging.getLogger("digitalmunshi.retriever")

# ── Paths ──
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
FAISS_DIR  = os.path.join(BASE_DIR, '../faiss_index')

# ── Global ──
_vectorstore = None
_embeddings  = None


class DocumentRetriever:
    def __init__(self):
        global _vectorstore, _embeddings

        # ── Embedding Model ──
        # RAG notebook mein BAAI/bge-small-en-v1.5 use hua tha
        try:
            try:
                from langchain_huggingface import HuggingFaceEmbeddings
            except ImportError:
                from langchain_community.embeddings import HuggingFaceEmbeddings
            _embeddings = HuggingFaceEmbeddings(
                model_name="BAAI/bge-small-en-v1.5",
                model_kwargs={"device": "cpu"},
                encode_kwargs={"normalize_embeddings": True}
            )
            print("✅ BAAI/bge-small-en-v1.5 embedding model loaded")
        except Exception as e:
            print(f"⚠️  Embedding model error: {e}")
            _embeddings = None

        # ── LangChain FAISS Load ──
        # Tumhara FAISS LangChain format mein save hua tha
        try:
            if _embeddings and os.path.exists(FAISS_DIR):
                from langchain_community.vectorstores import FAISS
                self._patch_pydantic_pickle_state()
                try:
                    _vectorstore = FAISS.load_local(
                        FAISS_DIR,
                        _embeddings,
                        allow_dangerous_deserialization=True
                    )
                except TypeError:
                    _vectorstore = FAISS.load_local(FAISS_DIR, _embeddings)
                print(f"✅ LangChain FAISS loaded from: {FAISS_DIR}")
            else:
                print(f"⚠️  FAISS load nahi hua — static fallback active")
                _vectorstore = None
        except Exception as e:
            print(f"⚠️  FAISS load error: {e}")
            print(f"   Static fallback active")
            _vectorstore = None

    @staticmethod
    def _patch_pydantic_pickle_state():
        """Allow older saved LangChain documents to unpickle under current Pydantic."""
        try:
            import pydantic.main as pydantic_main
        except Exception:
            return

        base_model = pydantic_main.BaseModel
        if getattr(base_model, "_digitalmunshi_pickle_patch", False):
            return

        original_setstate = base_model.__setstate__

        def patched_setstate(self, state):
            if "__fields_set__" not in state:
                state = {
                    **state,
                    "__fields_set__": set(state.get("__dict__", {}).keys()),
                }
            return original_setstate(self, state)

        base_model.__setstate__ = patched_setstate
        base_model._digitalmunshi_pickle_patch = True

    def retrieve(self, query: str, top_k: int = 5, category: str = None) -> List[dict]:
        """
        Query ke liye top-k relevant law chunks return karo.
        Category filter apply karo agar diya gaya ho.
        """
        if _vectorstore is not None:
            return self._langchain_retrieve(query, top_k, category)

        # Static fallback
        print("⚠️  Static fallback use ho raha hai")
        return self._static_fallback(category, top_k)

    def _langchain_retrieve(self, query: str, top_k: int, category: str) -> List[dict]:
        """LangChain FAISS se retrieval"""
        try:
            # Category filter ke saath search
            if category:
                try:
                    docs = _vectorstore.similarity_search(
                        query,
                        k=top_k,
                        filter={"category": category}
                    )
                    # Agar filtered results kam hain toh without filter try karo
                    if len(docs) < 2:
                        docs = _vectorstore.similarity_search(query, k=top_k)
                except Exception:
                    docs = _vectorstore.similarity_search(query, k=top_k)
            else:
                docs = _vectorstore.similarity_search(query, k=top_k)

            results = []
            for i, doc in enumerate(docs):
                content  = doc.page_content
                metadata = doc.metadata

                # Title aur section extract karo content se
                import re
                title   = metadata.get('title', '')
                section = metadata.get('section', '')

                # Agar title nahi hai toh content se extract karo
                if not title:
                    sec_match = re.search(
                        r'(Pakistan Penal Code|PPC|CrPC|MFLO|Transfer of Property|Registration Act|'
                        r'Punjab Rented|EOBI|Industrial|Consumer Protection|Stamp Act|'
                        r'Dissolution of Muslim|Guardian|Muslim Family)',
                        content, re.IGNORECASE
                    )
                    title = sec_match.group(0) if sec_match else f"{metadata.get('category', '')} Law"

                if not section:
                    sec_match = re.search(r'[Ss]ection\s+\d+[A-Za-z]?', content)
                    section   = sec_match.group(0) if sec_match else ''

                results.append({
                    'rank':             i + 1,
                    'title':            title,
                    'section':          section,
                    'content':          content[:500],
                    'body':             content[:500],
                    'category':         metadata.get('category', category or ''),
                    'source':           metadata.get('source', 'Pakistani Law'),
                    'similarity_score': round(0.95 - (i * 0.05), 3)
                })

            print(f"✅ Retrieved {len(results)} docs for: '{query[:50]}'")
            return results

        except Exception as e:
            print(f"❌ LangChain retrieval error: {e}")
            return self._static_fallback(category, top_k)

    def _static_fallback(self, category: str, top_k: int) -> List[dict]:
        """FAISS unavailable hone par static law sections"""
        fallback = {
            'Criminal': [
                {'title': 'Pakistan Penal Code', 'section': 'Section 379',
                 'content': 'Whoever commits theft shall be punished with imprisonment which may extend to three years, or with fine, or with both.',
                 'category': 'Criminal', 'source': 'PPC 1860'},
                {'title': 'Pakistan Penal Code', 'section': 'Section 302',
                 'content': 'Whoever commits qatl-i-amd shall be punished with death as qisas, or imprisonment for life as tazir.',
                 'category': 'Criminal', 'source': 'PPC 1860'},
                {'title': 'Code of Criminal Procedure', 'section': 'Section 154',
                 'content': 'Every information relating to a cognizable offence given orally to an officer in charge of a police station shall be reduced to writing.',
                 'category': 'Criminal', 'source': 'CrPC 1898'},
                {'title': 'Pakistan Penal Code', 'section': 'Section 420',
                 'content': 'Whoever cheats and thereby dishonestly induces the person deceived to deliver any property shall be punished with imprisonment up to seven years.',
                 'category': 'Criminal', 'source': 'PPC 1860'},
                {'title': 'Code of Criminal Procedure', 'section': 'Section 496',
                 'content': 'When any person accused of a bailable offence is arrested, such person shall be released on bail.',
                 'category': 'Criminal', 'source': 'CrPC 1898'},
            ],
            'Family': [
                {'title': 'Muslim Family Laws Ordinance', 'section': 'Section 7',
                 'content': 'Any man who wishes to divorce his wife shall give the Chairman notice in writing. Ninety days after receipt, talaq becomes effective.',
                 'category': 'Family', 'source': 'MFLO 1961'},
                {'title': 'Dissolution of Muslim Marriages Act', 'section': 'Section 2',
                 'content': 'A woman married under Muslim law shall be entitled to obtain a decree for dissolution of her marriage on grounds including cruelty.',
                 'category': 'Family', 'source': 'DMMA 1939'},
                {'title': 'Guardian and Wards Act', 'section': 'Section 17',
                 'content': 'In appointing the guardian of a minor, the Court shall be guided by what appears to be for the welfare of the minor.',
                 'category': 'Family', 'source': 'GWA 1890'},
                {'title': 'Muslim Family Laws Ordinance', 'section': 'Section 6',
                 'content': 'No man during subsistence of an existing marriage shall contract another marriage without written permission of Arbitration Council.',
                 'category': 'Family', 'source': 'MFLO 1961'},
                {'title': 'West Pakistan Muslim Personal Law', 'section': 'Section 3',
                 'content': 'In all questions regarding succession, marriage, divorce, dower, the rule of decision shall be the Muslim Personal Law.',
                 'category': 'Family', 'source': 'WPMPL 1962'},
            ],
            'Property': [
                {'title': 'Transfer of Property Act', 'section': 'Section 54',
                 'content': 'Sale of immoveable property of value Rs.100 and upwards can only be made by a registered instrument.',
                 'category': 'Property', 'source': 'TPA 1882'},
                {'title': 'Registration Act', 'section': 'Section 17',
                 'content': 'Registration is compulsory for instruments creating any right or title in immoveable property.',
                 'category': 'Property', 'source': 'RA 1908'},
                {'title': 'Land Revenue Act', 'section': 'Section 42',
                 'content': 'Every mutation shall be attested by a Revenue Officer not below the rank of a Field Qanungo.',
                 'category': 'Property', 'source': 'LRA 1967'},
                {'title': 'Stamp Act', 'section': 'Section 3',
                 'content': 'Every instrument executed in Pakistan shall be chargeable with stamp duty of the amount indicated in Schedule I.',
                 'category': 'Property', 'source': 'SA 1899'},
                {'title': 'Specific Relief Act', 'section': 'Section 12',
                 'content': 'Specific performance of a contract for transfer of immoveable property may be enforced by court.',
                 'category': 'Property', 'source': 'SRA 1877'},
            ],
            'Labor': [
                {'title': 'Industrial and Commercial Employment Ordinance', 'section': 'Section 12',
                 'content': 'No employer shall dismiss a workman unless a proper inquiry is conducted and workman is given opportunity to be heard.',
                 'category': 'Labor', 'source': 'ICEO 1968'},
                {'title': 'Payment of Wages Act', 'section': 'Section 4',
                 'content': 'Every employer shall be responsible for the payment of all wages to persons employed by him.',
                 'category': 'Labor', 'source': 'PWA 1936'},
                {'title': 'EOBI Act', 'section': 'Section 12',
                 'content': 'Every insured person shall be entitled to old-age pension on attaining the age of sixty years.',
                 'category': 'Labor', 'source': 'EOBI 1976'},
                {'title': 'Minimum Wages Ordinance', 'section': 'Section 3',
                 'content': 'The Provincial Government may fix minimum rates of wages for workers employed in any scheduled employment.',
                 'category': 'Labor', 'source': 'MWO 1961'},
                {'title': 'Workmen Compensation Act', 'section': 'Section 3',
                 'content': 'Employer shall be liable to pay compensation for injury caused to a workman during employment.',
                 'category': 'Labor', 'source': 'WCA 1923'},
            ],
            'Tenant': [
                {'title': 'Punjab Rented Premises Act', 'section': 'Section 12',
                 'content': 'A landlord shall not evict a tenant except with the prior permission of the Rent Controller.',
                 'category': 'Tenant', 'source': 'PRPA 2009'},
                {'title': 'Transfer of Property Act', 'section': 'Section 105',
                 'content': 'A lease of immoveable property is a transfer of a right to enjoy such property for a certain time.',
                 'category': 'Tenant', 'source': 'TPA 1882'},
                {'title': 'Punjab Rented Premises Act', 'section': 'Section 7',
                 'content': 'A landlord shall not increase the rent of rented premises within two years of commencement of tenancy.',
                 'category': 'Tenant', 'source': 'PRPA 2009'},
                {'title': 'Transfer of Property Act', 'section': 'Section 108',
                 'content': 'Lessor must disclose any material defect in the property to lessee.',
                 'category': 'Tenant', 'source': 'TPA 1882'},
                {'title': 'Punjab Rented Premises Act', 'section': 'Section 17',
                 'content': 'Tenant cannot sublet without written consent of landlord.',
                 'category': 'Tenant', 'source': 'PRPA 2009'},
            ],
            'Consumer': [
                {'title': 'Punjab Consumer Protection Act', 'section': 'Section 9',
                 'content': 'No person shall sell goods that do not conform to prescribed standards or are hazardous to consumers.',
                 'category': 'Consumer', 'source': 'PCPA 2005'},
                {'title': 'Consumer Protection Council Rules', 'section': 'Rule 4',
                 'content': 'A consumer may file a complaint for defective goods or deficient services provided by any trader.',
                 'category': 'Consumer', 'source': 'CPCR'},
                {'title': 'Pakistan Standards and Quality Control Authority Act', 'section': 'Section 13',
                 'content': 'No person shall manufacture or import any article for sale unless it conforms to Pakistan Standard.',
                 'category': 'Consumer', 'source': 'PSQCA 1996'},
                {'title': 'Drug Act', 'section': 'Section 23',
                 'content': 'No person shall sell any drug without a valid licence issued under this Act.',
                 'category': 'Consumer', 'source': 'DA 1976'},
                {'title': 'Weights and Measures Ordinance', 'section': 'Section 11',
                 'content': 'Only verified and stamped weights and measures may be used for trade.',
                 'category': 'Consumer', 'source': 'WMO 1976'},
            ],
        }

        category_docs = fallback.get(category, fallback['Criminal'])
        for i, doc in enumerate(category_docs):
            doc['rank']             = i + 1
            doc['document_id']      = i
            doc['body']             = doc['content']
            doc['similarity_score'] = round(0.90 - (i * 0.05), 3)

        print(f"📚 Static fallback: {len(category_docs[:top_k])} docs for '{category}'")
        return category_docs[:top_k]
